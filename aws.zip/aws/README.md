# A Mongoose app to send data to AWS IoT Core
